from ._common import client, sleep_ms

def test_lap_should_return_incremental_differences():
    """ねらい: lap の仕様をテストで“固定”する（回帰防止）

    ラップは「合計(total)」と「そのラップ区間(lap)」の2つを返す想定。
    - 1周目: lap_elapsed_ms は total とほぼ同じ（開始からの経過）
    - 2周目以降: lap_elapsed_ms は total の差分（前回 total との差）
    """
    c = client()
    c.post("/timer/start")

    sleep_ms(25)
    r1 = c.post("/timer/lap")
    assert r1.status_code == 201
    lap1 = r1.get_json()

    # ここまでは最低限の形チェック
    assert lap1["lap_index"] == 1
    assert "lap_elapsed_ms" in lap1
    assert "total_elapsed_ms" in lap1

    sleep_ms(25)
    r2 = c.post("/timer/lap")
    assert r2.status_code == 201
    lap2 = r2.get_json()
    assert lap2["lap_index"] == 2

    # ------------------------------
    # ▼▼ 模範解答の“核心”はここ ▼▼
    # （授業ではここを完成させる）
    # ------------------------------

    # 1) total は増えるはず
    # assert lap2["total_elapsed_ms"] > lap1["total_elapsed_ms"]

    # 2) 2周目の lap は「totalの差分」になるはず
    # diff = lap2["total_elapsed_ms"] - lap1["total_elapsed_ms"]
    # assert abs(lap2["lap_elapsed_ms"] - diff) <= 5

    # ↑ なぜこうする？
    # - lapが毎回 total と同じになってしまうバグ（差分計算ミス）をCIで止められる
    # - “ローカルで見た目が動く”だけでは検出しにくいロジックバグを守れる

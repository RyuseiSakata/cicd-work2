# Timer & Clock アプリケーション - 学習プロジェクト

## 📖 プロジェクト概要

このプロジェクトは、Flask（Python）とVanilla JavaScript を使ってWebアプリケーションを開発する学習教材です。
**仕様書からアプリケーションを実装する実践的な演習**を通じて、Web開発の基礎を習得できます。

### 機能
- ⏱️ **ストップウォッチ**: 高精度タイマー（ミリ秒単位）
- 🏃 **ラップ機能**: 区間タイムの記録
- 🌍 **世界時計**: 複数タイムゾーン対応の時計

## 🎯 学習目標

このプロジェクトを完成させると、以下のスキルが身につきます：

### バックエンド
- Flask による RESTful API 設計
- HTTPメソッド（GET/POST）の使い分け
- JSONレスポンスとステータスコードの適切な使用
- エラーハンドリングとバリデーション
- 状態管理とタイミング処理

### フロントエンド
- Vanilla JavaScript による動的UI構築
- Fetch API を使った非同期通信
- requestAnimationFrame による滑らかなアニメーション
- DOMイベントハンドリング
- ユーザーエクスペリエンスの設計

### 全体
- 仕様書からの要件抽出と実装
- API設計とエンドポイント定義
- クライアント・サーバー間の通信設計
- テストシナリオの作成と実行

## 📂 ファイル構成

```
.
├── SPEC.md                    # 📋 アプリケーション仕様書（最初に読む）
├── TRAINING_GUIDE.md          # 📚 学習ガイド（演習の進め方）
├── ANSWER_KEY.md              # 💡 解答例とヒント集（詰まったら参照）
├── PROJECT_README.md          # 📖 このファイル
│
├── [演習用ファイル]
├── timer_exercise.py          # 🔨 メインアプリケーション（虫食い）
├── lap_exercise.py            # 🔨 ラップ機能（虫食い）
├── world_clock_exercise.py    # 🔨 世界時計機能（虫食い）
├── index_exercise.html        # 🔨 フロントエンド（虫食い）
│
└── [完全版・参考用]
    ├── timer.py               # ✅ 完全版
    ├── lap.py                 # ✅ 完全版
    ├── world_clock.py         # ✅ 完全版
    ├── index.html             # ✅ 完全版
    └── app.py                 # ✅ エントリポイント
```

## 🚀 クイックスタート

### 前提条件
- Python 3.9 以上
- pip（Pythonパッケージマネージャー）
- モダンなWebブラウザ（Chrome, Firefox, Safari等）

### セットアップ

#### 1. リポジトリのクローン（または必要ファイルのダウンロード）
```bash
# ディレクトリ作成
mkdir timer-app-learning
cd timer-app-learning
```

#### 2. 仮想環境の作成（推奨）
```bash
python -m venv venv

# 有効化（Mac/Linux）
source venv/bin/activate

# 有効化（Windows）
venv\Scripts\activate
```

#### 3. 依存パッケージのインストール
```bash
pip install flask
```

#### 4. 完全版で動作確認（オプション）
```bash
# 完全版のアプリを実行して動作を確認
python timer.py
```

ブラウザで http://localhost:5050 にアクセスして、完成形の動作を確認できます。

### 演習の開始

#### Step 1: 仕様書を読む（30分）
```bash
# SPEC.md を開いて熟読
# - API仕様
# - データ構造
# - エラーケース
```

#### Step 2: 演習ファイルの準備
```bash
# timer_app ディレクトリを作成
mkdir timer_app
cd timer_app

# 演習用ファイルを配置
# - timer_exercise.py → timer.py に名前を変更
# - lap_exercise.py → lap.py に名前を変更
# - world_clock_exercise.py → world_clock.py に名前を変更

# templates ディレクトリを作成
mkdir templates

# index_exercise.html を templates/index.html に配置
```

#### Step 3: 実装を開始
```bash
# アプリを起動（実装しながら動作確認）
python timer.py
```

ブラウザで http://localhost:5050 にアクセスして、実装した機能を確認できます。

## 📝 学習の流れ

### Phase 1: 準備（30分）
1. **SPEC.md** を読んで要件を理解
2. **TRAINING_GUIDE.md** で演習の進め方を確認
3. 完全版アプリで動作を体験

### Phase 2: バックエンド実装（90分）

#### 2-1. 基本構造（20分）
- `timer_exercise.py` の TODO 1-1, 1-2
- 状態管理と時間計算

#### 2-2. APIエンドポイント（30分）
- `timer_exercise.py` の TODO 2-1 ~ 3-4
- GET/POST エンドポイントの実装
- エラーハンドリング

#### 2-3. ラップ機能（20分）
- `lap_exercise.py` の TODO 5-1 ~ 5-4
- ラップ時間の計算ロジック

#### 2-4. 世界時計（20分）
- `world_clock_exercise.py` の TODO 6-1 ~ 6-5
- タイムゾーン処理

### Phase 3: フロントエンド実装（60分）

#### 3-1. ユーティリティ（15分）
- `index_exercise.html` の TODO 7-1, 7-2
- 時間フォーマットとAPI通信

#### 3-2. タイマー表示（25分）
- TODO 7-3 ~ 7-5
- スムーズな時間表示

#### 3-3. イベント処理（20分）
- TODO 7-6 ~ 7-9
- ボタンと時計の実装

### Phase 4: テストと検証（30分）
- 手動テストの実行
- エッジケースの確認
- バグ修正

## 🧪 テスト方法

### 手動テスト
ブラウザでアプリにアクセスし、以下をテスト：

**タイマー基本動作**
1. Start → タイマー開始
2. Stop → タイマー停止
3. Start（再開） → 続きから開始
4. Reset → 0にリセット

**ラップ機能**
1. Start → Lap（3秒後） → Lap（2秒後）
2. ラップが正しく記録されているか確認

**エラーケース**
- 停止中に Stop → エラー無視
- 実行中に Start → エラー無視
- 実行中に Reset → エラー無視

### APIテスト（curl）
```bash
# ヘルスチェック
curl http://localhost:5050/health

# タイマー開始
curl -X POST http://localhost:5050/timer/start

# タイマー状態確認
curl http://localhost:5050/timer

# ラップ記録
curl -X POST http://localhost:5050/timer/lap

# タイマー停止
curl -X POST http://localhost:5050/timer/stop

# タイマーリセット
curl -X POST http://localhost:5050/timer/reset

# 世界時計（東京）
curl "http://localhost:5050/clock?tz=Asia/Tokyo"
```

## 💡 困ったときは

### 詰まったら
1. **TRAINING_GUIDE.md** のヒントセクションを確認
2. **ANSWER_KEY.md** で段階的に解答を確認
3. コンソールやログでエラーメッセージを確認
4. 完全版のコードと比較

### よくある問題

**問題**: タイマーが開始しない
- 解決: `global` 宣言を確認、state の更新を確認

**問題**: 時間がおかしい
- 解決: ミリ秒への変換（`* 1000`）を確認

**問題**: ラップ時間が間違っている
- 解決: 前回ラップとの差分計算を確認

**問題**: フロントエンドが更新されない
- 解決: `requestAnimationFrame()` の呼び出しを確認

## 🎓 次のステップ

演習を完了したら、以下の拡張機能に挑戦してみましょう：

### 初級
- [ ] カウントダウンタイマーの実装
- [ ] タイマー完了時の音声通知
- [ ] ダークモードの追加

### 中級
- [ ] 複数タイマーの同時動作
- [ ] ラップデータのCSVエクスポート
- [ ] タイマープリセットの保存機能

### 上級
- [ ] SQLiteでのデータ永続化
- [ ] ユーザー認証の実装
- [ ] WebSocketによるリアルタイム同期

## 📚 参考資料

### 公式ドキュメント
- Flask: https://flask.palletsprojects.com/
- MDN Web Docs: https://developer.mozilla.org/
- Python time module: https://docs.python.org/3/library/time.html

### 推奨学習リソース
- REST API設計: https://restfulapi.net/
- JavaScript Promises: https://javascript.info/promise-basics
- HTTP status codes: https://httpstatuses.com/

## 🤝 フィードバック

このプロジェクトを改善するためのフィードバックを歓迎します：
- わかりにくかった箇所
- 追加してほしい機能
- 難易度の感想

## 📄 ライセンス

このプロジェクトは学習目的で自由に使用・改変できます。

---

**Happy Coding! 🚀**

質問や問題があれば、遠慮なく質問してください。

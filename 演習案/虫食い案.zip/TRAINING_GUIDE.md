# Timer & Clock アプリ - 学習ガイド

## 📚 演習の目的

このプロジェクトでは、以下のスキルを習得できます：

1. **Flask によるWeb API設計**
   - RESTful APIの実装
   - HTTPステータスコードの適切な使用
   - エラーハンドリング

2. **状態管理**
   - グローバル変数を使った状態管理
   - タイミング計算（time.monotonic()）
   - データの整合性

3. **フロントエンド開発**
   - Vanilla JavaScript での動的UI
   - Fetch API による非同期通信
   - requestAnimationFrame による滑らかなアニメーション

4. **仕様からの実装**
   - 仕様書の読解
   - エッジケースの考慮
   - テストシナリオの作成

## 🎯 学習の進め方

### Step 1: 仕様書を理解する（30分）

1. **SPEC.md** を熟読
2. 以下の項目を特に重点的に確認：
   - API仕様（エンドポイント、レスポンス形式）
   - タイマーの状態遷移
   - 時間計算のロジック
   - エラーケース

3. 質問リストを作成：
   - 「なぜ time.monotonic() を使うのか？」
   - 「ラップ時間の計算方法は？」
   - 「クライアント側で時間を計算する理由は？」

### Step 2: バックエンドの実装（90分）

#### Phase 1: 基本構造（20分）
**ファイル**: `timer_exercise.py`

**TODO 1-1: 状態変数の定義**
```python
state = "stopped"
start_time = None
elapsed_ms = 0
laps = []
```

**理解度チェック**:
- Q: なぜ start_time は None で初期化するのか？
- A: タイマー停止中は開始時刻が存在しないため

**TODO 1-2: 経過時間の計算**
```python
if state == "running" and start_time is not None:
    return elapsed_ms + int((time.monotonic() - start_time) * 1000)
```

**理解度チェック**:
- Q: time.monotonic() の役割は？
- A: 単調増加する時間を取得（システムクロック変更の影響を受けない）

#### Phase 2: APIエンドポイント（30分）
**ファイル**: `timer_exercise.py`

**TODO 2-1, 2-2: GET エンドポイント**
```python
# ヘルスチェック
return jsonify({"status": "ok"}), 200

# タイマー状態取得
return jsonify({
    "state": state,
    "elapsed_ms": current_elapsed_ms(),
    "laps": laps
}), 200
```

**TODO 3-1 ~ 3-4: POST エンドポイント（Start/Stop）**

重要ポイント:
- 既に実行中/停止中のエラーハンドリング
- HTTPステータスコード 409 (Conflict) の使用
- グローバル変数の更新順序

#### Phase 3: ラップ機能（20分）
**ファイル**: `lap_exercise.py`

**TODO 5-1 ~ 5-4: ラップ記録**

計算ロジック:
```python
# 最初のラップ
if len(laps) == 0:
    lap_elapsed = total

# 2回目以降
else:
    lap_elapsed = total - laps[-1]["total_elapsed_ms"]
```

**理解度チェック**:
- Q: なぜ laps[-1] を使うのか？
- A: 直前のラップ（最後の要素）を取得するため

#### Phase 4: 世界時計（20分）
**ファイル**: `world_clock_exercise.py`

**TODO 6-1 ~ 6-5: 時計API**

```python
ALLOWED_TZ = {
    "UTC": "UTC",
    "Asia/Tokyo": "Asia/Tokyo",
    "America/New_York": "America/New_York",
    "Europe/London": "Europe/London",
}

tz = request.args.get("tz", "UTC")
now = datetime.now(ZoneInfo(ALLOWED_TZ[tz]))
```

### Step 3: フロントエンド実装（60分）

#### Phase 1: ユーティリティ関数（15分）
**ファイル**: `index_exercise.html`

**TODO 7-1: 時間フォーマット**
```javascript
function fmt(ms) {
  const m = Math.floor(ms / 60000);
  const s = Math.floor((ms % 60000) / 1000);
  const r = ms % 1000;
  return String(m).padStart(2, '0') + ":" + 
         String(s).padStart(2, '0') + "." + 
         String(r).padStart(3, '0');
}
```

**TODO 7-2: API呼び出し**
```javascript
async function api(path, method = "GET") {
  const res = await fetch(path, { method: method });
  const body = await res.json().catch(() => ({}));
  if (!res.ok) throw { status: res.status, body };
  return body;
}
```

#### Phase 2: タイマー表示（25分）

**TODO 7-3: ラップ描画**
```javascript
for (const lap of laps) {
  const li = document.createElement("li");
  li.textContent = `#${lap.lap_index}  lap=${fmt(lap.lap_elapsed_ms)}  total=${fmt(lap.total_elapsed_ms)}`;
  ul.appendChild(li);
}
```

**TODO 7-4: サーバー同期**
```javascript
const t = await api("/timer");
t_state = t.state;
baseElapsed = t.elapsed_ms;
startAt = (t_state === "running") ? performance.now() : null;
```

**TODO 7-5: 滑らかな表示**
```javascript
let ms = baseElapsed;
if (t_state === "running" && startAt !== null) {
  ms += Math.floor(performance.now() - startAt);
}
$("time").textContent = fmt(ms);
requestAnimationFrame(renderTimer);
```

**重要**: requestAnimationFrame の役割
- 60fps で呼び出される
- ブラウザの描画タイミングに同期
- サーバー通信なしで滑らかな表示

#### Phase 3: イベントハンドラ（20分）

**TODO 7-6: ボタンイベント**
```javascript
$("start").onclick = async () => {
  try {
    await api("/timer/start", "POST");
  } catch (e) { }
  await syncTimer();
};
```

**TODO 7-7 ~ 7-9: 時計機能**
```javascript
async function syncClock() {
  const tz = $("tz").value;
  const data = await api(`/clock?tz=${encodeURIComponent(tz)}`);
  $("clock-time").textContent = data.iso.replace("T", " ").split(".")[0];
  $("clock-iso").textContent = `iso=${data.iso}  epoch_ms=${data.epoch_ms}`;
}

setInterval(() => {
  if (mode === "clock") syncClock().catch(() => { });
}, 1000);
```

## 🧪 テストシナリオ

### 手動テスト

#### Test 1: 基本動作
1. Startボタンをクリック → タイマー開始
2. 3秒待つ → 約3000ms表示
3. Stopボタンをクリック → タイマー停止
4. 表示が止まることを確認
5. Startボタンをクリック → 続きから開始
6. Resetボタンをクリック → 0にリセット

#### Test 2: ラップ機能
1. Start → Lap（3秒後） → Lap（5秒後）
2. ラップ一覧を確認：
   - #1: lap=約3000ms, total=約3000ms
   - #2: lap=約2000ms, total=約5000ms

#### Test 3: エラーケース
1. 停止中にStopをクリック → エラー（無視される）
2. 実行中にStartをクリック → エラー（無視される）
3. 停止中にLapをクリック → エラー（無視される）
4. 実行中にResetをクリック → エラー（無視される）

#### Test 4: 世界時計
1. Clockタブをクリック
2. タイムゾーンを切り替え → 正しい時刻が表示される
3. 1秒待つ → 自動更新される

### APIテスト（curlまたはPostman）

```bash
# ヘルスチェック
curl http://localhost:5050/health

# タイマー開始
curl -X POST http://localhost:5050/timer/start

# タイマー状態取得
curl http://localhost:5050/timer

# ラップ記録
curl -X POST http://localhost:5050/timer/lap

# タイマー停止
curl -X POST http://localhost:5050/timer/stop

# タイマーリセット
curl -X POST http://localhost:5050/timer/reset

# 世界時計
curl "http://localhost:5050/clock?tz=Asia/Tokyo"
```

## 🐛 よくある問題とデバッグ

### 問題1: タイマーが開始しない
**症状**: Startボタンを押しても何も起きない
**原因**: 
- state が正しく更新されていない
- start_time が設定されていない
**解決**: global 宣言を確認

### 問題2: 経過時間がおかしい
**症状**: 時間が飛んだり、マイナスになる
**原因**: 
- time.monotonic() の単位（秒）をミリ秒に変換していない
- elapsed_ms の更新タイミングが不適切
**解決**: `* 1000` を確認、Stop時に elapsed_ms を更新

### 問題3: ラップ時間の計算が間違っている
**症状**: ラップタイムが累積時間と同じ
**原因**: 前回のラップからの差分計算が不正
**解決**: `total - laps[-1]["total_elapsed_ms"]` を確認

### 問題4: フロントエンドでタイマーが更新されない
**症状**: 表示が00:00.000のまま
**原因**: 
- renderTimer() が呼ばれていない
- performance.now() の計算が間違っている
**解決**: requestAnimationFrame の呼び出しを確認

## 📖 追加学習リソース

### Flask
- 公式ドキュメント: https://flask.palletsprojects.com/
- RESTful API設計: https://restfulapi.net/

### JavaScript
- MDN Web Docs: https://developer.mozilla.org/ja/
- Fetch API: https://developer.mozilla.org/ja/docs/Web/API/Fetch_API
- requestAnimationFrame: https://developer.mozilla.org/ja/docs/Web/API/window/requestAnimationFrame

### Python タイミング
- time.monotonic(): https://docs.python.org/ja/3/library/time.html#time.monotonic
- datetime と zoneinfo: https://docs.python.org/ja/3/library/zoneinfo.html

## 🚀 次のステップ

演習が完了したら、以下の拡張機能に挑戦してみましょう：

### Level 1: 基本拡張
1. **カウントダウンタイマー**: 指定時間からのカウントダウン
2. **音声通知**: タイマー完了時に音を鳴らす
3. **ダークモード**: CSSで切り替え可能に

### Level 2: 中級拡張
1. **複数タイマー**: 同時に複数のタイマーを動作
2. **ラップエクスポート**: CSV/JSON形式でダウンロード
3. **プリセット機能**: タイマー設定の保存・読み込み

### Level 3: 上級拡張
1. **データベース連携**: タイマー履歴をDBに保存
2. **ユーザー認証**: ログイン機能の追加
3. **リアルタイム同期**: WebSocketで複数デバイス間で同期

## 💡 設計の考え方

### なぜこの設計なのか？

#### 1. サーバー側は最小限の計算
- クライアントが主体的に時間を計算
- サーバーは状態変更時のみ関与
- スケーラビリティの向上

#### 2. time.monotonic() の使用
- システムクロックの変更に影響されない
- NTPによる時刻同期の影響を受けない
- より正確な時間計測

#### 3. requestAnimationFrame の使用
- ブラウザの描画サイクルに同期
- バッテリー消費の最適化
- タブが非アクティブ時は自動的に停止

#### 4. エラーの静かな無視
- UXの向上（エラーメッセージを表示しない）
- 状態の再同期で自動修復
- ユーザーが混乱しない

## 🎓 評価基準

以下の観点で自己評価してみましょう：

### 機能性（40点）
- [ ] タイマーの開始・停止が正しく動作する（10点）
- [ ] ラップ機能が正常に動作する（10点）
- [ ] リセット機能が正常に動作する（5点）
- [ ] 世界時計が正しく表示される（10点）
- [ ] エラーケースが適切に処理される（5点）

### コード品質（30点）
- [ ] 変数名が適切で理解しやすい（5点）
- [ ] コメントが適切に記述されている（5点）
- [ ] DRY原則に従っている（5点）
- [ ] エラーハンドリングが適切（10点）
- [ ] コードの可読性が高い（5点）

### 理解度（30点）
- [ ] 仕様書を理解している（10点）
- [ ] API設計の意図を理解している（10点）
- [ ] 時間計算のロジックを説明できる（10点）

**合計: 100点**

85点以上: 優秀！次の拡張機能に挑戦
70-84点: 良好。エッジケースを再確認
70点未満: 基本部分を復習してから次へ

## 📝 学習記録テンプレート

```markdown
# 学習記録

## 実装日
2024-XX-XX

## 実装時間
- バックエンド: XX時間
- フロントエンド: XX時間
- テスト: XX時間

## 苦戦したポイント
1. 
2. 
3. 

## 学んだこと
1. 
2. 
3. 

## 次回への課題
1. 
2. 
3. 
```

頑張ってください！🎉

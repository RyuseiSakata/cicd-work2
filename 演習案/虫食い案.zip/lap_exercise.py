from flask import jsonify


def register_lap_routes(app, current_elapsed_ms, get_state, get_laps):
    """
    ラップ機能のエンドポイントを登録
    
    Parameters:
        app: Flask アプリケーションインスタンス
        current_elapsed_ms: 現在の経過時間を取得する関数
        get_state: 現在の状態を取得する関数
        get_laps: ラップ一覧を取得する関数
    """

    @app.post("/timer/lap")
    def lap_timer():
        """
        ラップを記録する
        
        ラップタイムの計算:
        - 最初のラップ: 開始からの経過時間
        - 2回目以降: 前回ラップからの経過時間
        
        Returns:
            201: ラップ記録成功
            409: タイマーが停止中
        """
        # TODO 5-1: タイマーが実行中でない場合はエラーを返す
        # ヒント: get_state() で状態を取得
        # ヒント: エラーコードは "NOT_RUNNING"
        if ____:
            return jsonify({"error": ____}), ____
        
        # 現在のラップ一覧と経過時間を取得
        laps = get_laps()
        total = current_elapsed_ms()
        
        # TODO 5-2: ラップ経過時間を計算
        # 最初のラップの場合: 開始からの経過時間（total）
        # 2回目以降のラップ: 現在時刻 - 前回ラップの累積時間
        if len(laps) == ____:
            # 最初のラップ
            lap_elapsed = ____
        else:
            # 2回目以降のラップ
            # ヒント: laps[-1]["total_elapsed_ms"] で前回の累積時間を取得
            lap_elapsed = ____ - ____
        
        # TODO 5-3: ラップ情報を作成
        # - lap_index: 何番目のラップか（1から開始）
        # - lap_elapsed_ms: このラップの経過時間
        # - total_elapsed_ms: 開始からの累積時間
        lap = {
            "lap_index": ____,      # ヒント: len(laps) + 1
            "lap_elapsed_ms": ____,
            "total_elapsed_ms": ____,
        }
        
        # ラップ一覧に追加
        laps.append(lap)
        
        # TODO 5-4: 作成したラップ情報を返す
        # ヒント: HTTPステータス 201 (Created)
        return ____, ____

    return lap_timer

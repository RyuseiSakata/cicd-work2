# Timer & Clock アプリケーション仕様書

## 1. 概要

本アプリケーションは、ストップウォッチ機能と世界時計機能を提供するWebアプリケーションです。
Flask（Python）でバックエンドAPI、HTML/JavaScriptでフロントエンドを実装します。

## 2. 機能要件

### 2.1 タイマー機能（ストップウォッチ）

#### 2.1.1 基本動作
- **Start**: タイマーを開始する
- **Stop**: タイマーを停止する
- **Lap**: 現在の経過時間を記録する（ラップタイム）
- **Reset**: タイマーをリセットする（停止状態でのみ可能）

#### 2.1.2 状態管理
- タイマーは `running`（動作中）または `stopped`（停止中）の状態を持つ
- 初期状態は `stopped`
- 経過時間はミリ秒単位で管理

#### 2.1.3 時間計算
- **経過時間**: タイマー開始からの累積時間（ms）
- **ラップ時間**: 前回のラップからの経過時間（ms）
  - 最初のラップ: 開始からの経過時間
  - 2回目以降: 前回ラップから現在までの経過時間

#### 2.1.4 ラップ記録
各ラップには以下の情報を含む：
```json
{
  "lap_index": 1,              // ラップ番号（1から開始）
  "lap_elapsed_ms": 5234,      // このラップの経過時間（ms）
  "total_elapsed_ms": 5234     // 開始からの累積時間（ms）
}
```

### 2.2 世界時計機能

#### 2.2.1 対応タイムゾーン
- `UTC`: 協定世界時
- `Asia/Tokyo`: 日本時間（JST）
- `America/New_York`: ニューヨーク時間（EST/EDT）
- `Europe/London`: ロンドン時間（GMT/BST）

#### 2.2.2 時刻情報
返却する情報：
```json
{
  "tz": "Asia/Tokyo",
  "iso": "2024-12-18T14:30:45.123456+09:00",
  "epoch_ms": 1702876245123
}
```

## 3. API仕様

### 3.1 共通仕様

#### Base URL
```
http://localhost:5050
```

#### レスポンス形式
- Content-Type: `application/json`
- 成功時: HTTPステータス 200/201
- エラー時: HTTPステータス 4xx/5xx、エラー詳細を含むJSON

### 3.2 エンドポイント一覧

#### 3.2.1 ヘルスチェック

```http
GET /health
```

**レスポンス**
```json
{
  "status": "ok"
}
```

#### 3.2.2 タイマー状態取得

```http
GET /timer
```

**レスポンス**
```json
{
  "state": "running",
  "elapsed_ms": 12345,
  "laps": [
    {
      "lap_index": 1,
      "lap_elapsed_ms": 5234,
      "total_elapsed_ms": 5234
    }
  ]
}
```

#### 3.2.3 タイマー開始

```http
POST /timer/start
```

**成功時（200）**
```json
{
  "state": "running",
  "elapsed_ms": 0
}
```

**エラー: 既に実行中（409 Conflict）**
```json
{
  "error": "ALREADY_RUNNING"
}
```

#### 3.2.4 タイマー停止

```http
POST /timer/stop
```

**成功時（200）**
```json
{
  "state": "stopped",
  "elapsed_ms": 12345
}
```

**エラー: 既に停止中（409 Conflict）**
```json
{
  "error": "ALREADY_STOPPED"
}
```

#### 3.2.5 ラップ記録

```http
POST /timer/lap
```

**成功時（201 Created）**
```json
{
  "lap_index": 2,
  "lap_elapsed_ms": 3456,
  "total_elapsed_ms": 8690
}
```

**エラー: タイマーが停止中（409 Conflict）**
```json
{
  "error": "NOT_RUNNING"
}
```

#### 3.2.6 タイマーリセット

```http
POST /timer/reset
```

**成功時（200）**
```json
{
  "state": "stopped",
  "elapsed_ms": 0,
  "laps": []
}
```

**エラー: タイマーが実行中（409 Conflict）**
```json
{
  "error": "CANNOT_RESET_WHILE_RUNNING"
}
```

#### 3.2.7 世界時計取得

```http
GET /clock?tz=Asia/Tokyo
```

**パラメータ**
- `tz` (optional): タイムゾーン（デフォルト: UTC）

**成功時（200）**
```json
{
  "tz": "Asia/Tokyo",
  "iso": "2024-12-18T14:30:45.123456+09:00",
  "epoch_ms": 1702876245123
}
```

**エラー: 無効なタイムゾーン（400 Bad Request）**
```json
{
  "error": "INVALID_TIMEZONE"
}
```

## 4. フロントエンド仕様

### 4.1 画面構成

#### 4.1.1 タイマー画面
- **現在の状態表示**: running / stopped
- **経過時間表示**: MM:SS.mmm 形式（分:秒.ミリ秒）
- **操作ボタン**: Start, Stop, Lap, Reset
- **ラップ一覧**: 記録された全ラップの表示

#### 4.1.2 時計画面
- **タイムゾーン選択**: ドロップダウンメニュー
- **現在時刻表示**: 大きく読みやすく
- **ISO形式表示**: 詳細な時刻情報
- **Refreshボタン**: 手動更新
- **自動更新**: 1秒ごとに時刻を更新

### 4.2 UI/UX要件

#### 4.2.1 タイマー表示
- 経過時間はスムーズに更新（クライアント側でrequestAnimationFrame使用）
- サーバーとの同期は操作時のみ
- ミリ秒まで正確に表示

#### 4.2.2 ボタン制御
- 不正な操作時はエラーを無視（サーバー側で制御）
- ボタン押下後、即座にUI更新

#### 4.2.3 モード切り替え
- Timer / Clock のタブ切り替え
- アクティブなタブはハイライト表示
- 非アクティブなエリアは非表示

## 5. 技術仕様

### 5.1 バックエンド

#### 5.1.1 使用技術
- Python 3.x
- Flask（Webフレームワーク）
- time.monotonic()（高精度タイマー）
- zoneinfo（タイムゾーン処理）

#### 5.1.2 時間管理
```python
# 実行中の経過時間計算
if state == "running":
    current_time = elapsed_ms + (time.monotonic() - start_time) * 1000
else:
    current_time = elapsed_ms
```

#### 5.1.3 モジュール構成
```
timer_app/
├── timer.py          # メインアプリケーション
├── lap.py            # ラップ機能
├── world_clock.py    # 世界時計機能
├── app.py            # エントリポイント
└── templates/
    └── index.html    # フロントエンド
```

### 5.2 フロントエンド

#### 5.2.1 使用技術
- HTML5
- Vanilla JavaScript（フレームワークなし）
- Fetch API（HTTP通信）

#### 5.2.2 時間表示フォーマット
```javascript
function fmt(ms) {
  const m = Math.floor(ms / 60000);           // 分
  const s = Math.floor((ms % 60000) / 1000);  // 秒
  const r = ms % 1000;                        // ミリ秒
  return `${m.toString().padStart(2, '0')}:${s.toString().padStart(2, '0')}.${r.toString().padStart(3, '0')}`;
}
```

## 6. エラーハンドリング

### 6.1 バックエンドエラー

| エラーコード | HTTPステータス | 説明 |
|------------|--------------|------|
| ALREADY_RUNNING | 409 | タイマーが既に実行中 |
| ALREADY_STOPPED | 409 | タイマーが既に停止中 |
| NOT_RUNNING | 409 | タイマーが停止中（Lap時） |
| CANNOT_RESET_WHILE_RUNNING | 409 | 実行中はリセット不可 |
| INVALID_TIMEZONE | 400 | 無効なタイムゾーン指定 |

### 6.2 フロントエンドエラー処理
- API呼び出し失敗時は静かにエラーを無視
- エラー後は `/timer` エンドポイントで状態を再同期

## 7. 非機能要件

### 7.1 パフォーマンス
- タイマー表示は60fps でスムーズに更新
- API レスポンスタイムは100ms以内（ローカル環境）

### 7.2 精度
- 時間計測精度: ±10ms
- 表示精度: 1ms

### 7.3 ユーザビリティ
- ボタンは大きく押しやすいサイズ
- 経過時間は視認性の高いフォント（monospace、44px）
- レスポンシブデザイン（最大幅820px）

## 8. テストシナリオ

### 8.1 タイマー基本動作
1. Startボタン → タイマー開始、状態がrunningに
2. Stopボタン → タイマー停止、経過時間が保持される
3. Startボタン（再開） → 前回の続きから計測
4. Resetボタン → 0にリセット

### 8.2 ラップ機能
1. Start → 3秒待つ → Lap → ラップ1記録（約3000ms）
2. さらに2秒待つ → Lap → ラップ2記録（約2000ms、累積5000ms）
3. ラップ一覧に正しく表示されることを確認

### 8.3 エラーケース
1. 停止中にStopボタン → エラー（ALREADY_STOPPED）
2. 実行中にStartボタン → エラー（ALREADY_RUNNING）
3. 停止中にLapボタン → エラー（NOT_RUNNING）
4. 実行中にResetボタン → エラー（CANNOT_RESET_WHILE_RUNNING）

### 8.4 世界時計
1. タイムゾーン変更 → 正しい時刻が表示される
2. 自動更新 → 1秒ごとに時刻が更新される
3. 無効なタイムゾーン → エラー（INVALID_TIMEZONE）

## 9. 実装の優先順位

### Phase 1: 基本タイマー
1. ヘルスチェックAPI
2. タイマー状態取得API
3. Start/Stop API実装
4. フロントエンド基本UI

### Phase 2: ラップ機能
1. Lap API実装
2. ラップ表示UI

### Phase 3: リセット機能
1. Reset API実装
2. エラーハンドリング

### Phase 4: 世界時計
1. Clock API実装
2. タイムゾーン選択UI
3. 自動更新機能

## 10. 拡張アイデア

将来的な機能追加案：
- カウントダウンタイマー
- 複数タイマーの同時動作
- ラップのエクスポート（CSV/JSON）
- タイマーのプリセット保存
- 音声通知機能
- ダークモード対応

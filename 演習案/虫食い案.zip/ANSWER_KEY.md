# 解答例とヒント集

## 🎯 このファイルの使い方

1. **まずは自力で実装**: 解答を見る前に、仕様書とTODOコメントを頼りに実装してみましょう
2. **詰まったら段階的に確認**: 
   - Level 1: ヒントセクションを読む
   - Level 2: 部分的な解答を見る
   - Level 3: 完全な解答を見る
3. **理解を深める**: コードをコピペするのではなく、なぜそうなるのか考えながら実装

---

## バックエンド解答

### timer_exercise.py

#### TODO 1-1: 状態変数の定義

**ヒント**:
- タイマーの初期状態は何か？
- ラップは最初はいくつある？

**解答**:
```python
state = "stopped"
start_time = None
elapsed_ms = 0
laps = []
```

**解説**:
- `state`: 文字列で状態を管理。"stopped" または "running"
- `start_time`: タイマー開始時の基準時刻。停止中は None
- `elapsed_ms`: 停止時点までの累積時間（整数）
- `laps`: リストでラップを管理。初期は空リスト

---

#### TODO 1-2: 経過時間の計算

**ヒント**:
- 実行中かどうかはどの変数で判断する？
- time.monotonic() は何の単位？
- 返り値はミリ秒単位

**部分解答**:
```python
if state == ____ and start_time is not None:
    return elapsed_ms + int((time.monotonic() - start_time) * 1000)
```

**完全解答**:
```python
if state == "running" and start_time is not None:
    return elapsed_ms + int((time.monotonic() - start_time) * 1000)
```

**解説**:
- `time.monotonic()` は秒単位なので、1000倍してミリ秒に変換
- 累積時間 + 今回の実行分を合計
- `int()` でミリ秒を整数にキャスト

---

#### TODO 2-1: ヘルスチェック

**解答**:
```python
return jsonify({"status": "ok"}), 200
```

**解説**:
- 単純なJSON応答
- HTTPステータス 200 (OK) を返す

---

#### TODO 2-2: タイマー状態取得

**解答**:
```python
return jsonify({
    "state": state,
    "elapsed_ms": current_elapsed_ms(),
    "laps": laps
}), 200
```

**解説**:
- 3つの情報を返す
- `current_elapsed_ms()` で現在の経過時間を計算
- laps はそのまま返す

---

#### TODO 3-1: 既に実行中のチェック

**ヒント**:
- エラーコードは "ALREADY_RUNNING"
- HTTPステータスは 409 (Conflict)

**解答**:
```python
if state == "running":
    return jsonify({"error": "ALREADY_RUNNING"}), 409
```

**解説**:
- 409 Conflictは「リクエストが現在の状態と矛盾している」という意味
- 重複開始を防ぐ

---

#### TODO 3-2: タイマー開始処理

**解答**:
```python
state = "running"
start_time = time.monotonic()
```

**解説**:
- 状態を変更
- 現在時刻を基準点として保存

---

#### TODO 3-3: 既に停止中のチェック

**解答**:
```python
if state == "stopped":
    return jsonify({"error": "ALREADY_STOPPED"}), 409
```

---

#### TODO 3-4: タイマー停止処理

**ヒント**:
- どの順番で変数を更新する？
- elapsed_ms は何を代入する？

**解答**:
```python
elapsed_ms = current_elapsed_ms()
start_time = None
state = "stopped"
```

**解説**:
- **重要**: elapsed_ms を先に更新する
- この時点で累積時間を確定
- start_time をクリア
- 状態を stopped に変更

---

#### TODO 4-1: 実行中はリセット不可

**解答**:
```python
if state == "running":
    return jsonify({"error": "CANNOT_RESET_WHILE_RUNNING"}), 409
```

---

#### TODO 4-2: タイマーリセット

**解答**:
```python
state = "stopped"
start_time = None
elapsed_ms = 0
laps = []
```

**解説**:
- すべてを初期状態に戻す
- ラップも空にする

---

### lap_exercise.py

#### TODO 5-1: 実行中チェック

**解答**:
```python
if get_state() != "running":
    return jsonify({"error": "NOT_RUNNING"}), 409
```

**解説**:
- 関数で状態を取得
- 停止中はラップを記録できない

---

#### TODO 5-2: ラップ経過時間の計算

**ヒント**:
- 最初のラップは特別なケース
- 2回目以降は前回からの差分

**部分解答**:
```python
if len(laps) == 0:
    lap_elapsed = total
else:
    lap_elapsed = total - laps[____][________]
```

**完全解答**:
```python
if len(laps) == 0:
    lap_elapsed = total
else:
    lap_elapsed = total - laps[-1]["total_elapsed_ms"]
```

**解説**:
- `laps[-1]` で最後の要素を取得
- 現在時刻 - 前回の累積時刻 = 今回のラップ時間

---

#### TODO 5-3: ラップ情報の作成

**解答**:
```python
lap = {
    "lap_index": len(laps) + 1,
    "lap_elapsed_ms": lap_elapsed,
    "total_elapsed_ms": total,
}
```

**解説**:
- lap_index は 1 から始まる
- 現在のラップ数 + 1

---

#### TODO 5-4: ラップ情報を返す

**解答**:
```python
return jsonify(lap), 201
```

**解説**:
- HTTPステータス 201 (Created) を使用
- 新しいリソースが作成されたことを示す

---

### world_clock_exercise.py

#### TODO 6-1: タイムゾーン辞書

**解答**:
```python
ALLOWED_TZ = {
    "UTC": "UTC",
    "Asia/Tokyo": "Asia/Tokyo",
    "America/New_York": "America/New_York",
    "Europe/London": "Europe/London",
}
```

**解説**:
- キーと値が同じでOK
- ZoneInfo に渡す文字列を定義

---

#### TODO 6-2: クエリパラメータ取得

**解答**:
```python
tz = request.args.get("tz", "UTC")
```

**解説**:
- `request.args.get()` でクエリパラメータを取得
- 第2引数がデフォルト値

---

#### TODO 6-3: タイムゾーン検証

**解答**:
```python
if tz not in ALLOWED_TZ:
    return jsonify({"error": "INVALID_TIMEZONE"}), 400
```

**解説**:
- 400 Bad Request は「不正なリクエスト」を示す
- 許可リストに含まれているか確認

---

#### TODO 6-4: 現在時刻の取得

**解答**:
```python
now = datetime.now(ZoneInfo(ALLOWED_TZ[tz]))
```

**解説**:
- `datetime.now()` にタイムゾーンを渡す
- `ZoneInfo()` でタイムゾーンオブジェクトを作成

---

#### TODO 6-5: レスポンスの作成

**解答**:
```python
return (
    jsonify({
        "tz": tz,
        "iso": now.isoformat(),
        "epoch_ms": int(now.timestamp() * 1000),
    }),
    200,
)
```

**解説**:
- `isoformat()`: ISO 8601形式の文字列
- `timestamp()`: Unix エポックからの秒数
- 1000倍してミリ秒に変換

---

## フロントエンド解答

### index_exercise.html

#### TODO 7-1: 時間フォーマット

**ヒント**:
- 1分 = 60000ミリ秒
- 1秒 = 1000ミリ秒
- 余り演算子 `%` を活用

**部分解答**:
```javascript
const m = Math.floor(ms / 60000);
const s = Math.floor((ms % ____) / 1000);
const r = ms % ____;
```

**完全解答**:
```javascript
function fmt(ms) {
  const m = Math.floor(ms / 60000);
  const s = Math.floor((ms % 60000) / 1000);
  const r = ms % 1000;
  return String(m).padStart(2, '0') + ":" + 
         String(s).padStart(2, '0') + "." + 
         String(r).padStart(3, '0');
}
```

**解説**:
- `Math.floor()`: 小数点以下切り捨て
- `padStart(2, '0')`: 2桁にゼロ埋め
- 例: 65432ms → "01:05.432"

---

#### TODO 7-2: API呼び出し

**解答**:
```javascript
async function api(path, method = "GET") {
  const res = await fetch(path, { method: method });
  const body = await res.json().catch(() => ({}));
  if (!res.ok) throw { status: res.status, body };
  return body;
}
```

**解説**:
- `fetch()` で非同期HTTP通信
- `res.json()` でJSON解析
- `.catch(() => ({}))` でパースエラーを無視

---

#### TODO 7-3: ラップ描画

**ヒント**:
- テンプレートリテラルを使う
- fmt() 関数で時間をフォーマット

**解答**:
```javascript
for (const lap of laps) {
  const li = document.createElement("li");
  li.textContent = `#${lap.lap_index}  lap=${fmt(lap.lap_elapsed_ms)}  total=${fmt(lap.total_elapsed_ms)}`;
  ul.appendChild(li);
}
```

**解説**:
- `document.createElement()` で要素作成
- テンプレートリテラルで文字列結合
- `appendChild()` でDOMに追加

---

#### TODO 7-4: サーバー同期

**解答**:
```javascript
async function syncTimer() {
  const t = await api("/timer");
  t_state = t.state;
  baseElapsed = t.elapsed_ms;
  startAt = (t_state === "running") ? performance.now() : null;
  $("state").textContent = t_state;
  renderLaps(t.laps || []);
}
```

**解説**:
- APIからデータ取得
- ローカル変数を更新
- 実行中の場合は performance.now() で基準点を記録

---

#### TODO 7-5: タイマー表示更新

**解答**:
```javascript
function renderTimer() {
  let ms = baseElapsed;
  if (t_state === "running" && startAt !== null) {
    ms += Math.floor(performance.now() - startAt);
  }
  $("time").textContent = fmt(ms);
  requestAnimationFrame(renderTimer);
}
```

**解説**:
- `performance.now()` は高精度タイマー
- 基準点からの経過時間を加算
- `requestAnimationFrame()` で次フレームを予約

---

#### TODO 7-6: ボタンイベント

**ヒント**:
- try-catch でエラーを無視
- API呼び出し後は syncTimer()

**解答**:
```javascript
// Start
$("start").onclick = async () => {
  try {
    await api("/timer/start", "POST");
  } catch (e) { }
  await syncTimer();
};

// Stop
$("stop").onclick = async () => {
  try {
    await api("/timer/stop", "POST");
  } catch (e) { }
  await syncTimer();
};

// Lap
$("lap").onclick = async () => {
  try {
    await api("/timer/lap", "POST");
  } catch (e) { }
  await syncTimer();
};

// Reset
$("reset").onclick = async () => {
  try {
    await api("/timer/reset", "POST");
  } catch (e) { }
  await syncTimer();
};
```

**解説**:
- エラーは静かに無視（UX向上）
- 状態を再同期して整合性を保つ

---

#### TODO 7-7: 時計更新

**解答**:
```javascript
async function syncClock() {
  const tz = $("tz").value;
  const data = await api(`/clock?tz=${encodeURIComponent(tz)}`);
  $("clock-time").textContent = data.iso.replace("T", " ").split(".")[0];
  $("clock-iso").textContent = `iso=${data.iso}  epoch_ms=${data.epoch_ms}`;
}
```

**解説**:
- `encodeURIComponent()` でURLエンコード
- `.replace("T", " ")` で見やすく整形
- `.split(".")[0]` でミリ秒以下を削除

---

#### TODO 7-8: 時計イベント

**解答**:
```javascript
$("clock-refresh").onclick = syncClock;
$("tz").onchange = syncClock;
```

**解説**:
- 関数自体を渡す（呼び出さない）
- イベント発生時に自動実行

---

#### TODO 7-9: 自動更新

**解答**:
```javascript
setInterval(() => {
  if (mode === "clock") syncClock().catch(() => { });
}, 1000);
```

**解説**:
- 1000ms = 1秒ごとに実行
- clock モードの時だけ更新
- `.catch()` でエラーを無視

---

## よくある間違い

### 間違い 1: global 宣言忘れ
```python
# ❌ 間違い
def start_timer():
    state = "running"  # ローカル変数になる

# ✅ 正しい
def start_timer():
    global state
    state = "running"
```

### 間違い 2: 時間の単位変換忘れ
```python
# ❌ 間違い（秒のまま）
return elapsed_ms + (time.monotonic() - start_time)

# ✅ 正しい（ミリ秒に変換）
return elapsed_ms + int((time.monotonic() - start_time) * 1000)
```

### 間違い 3: ラップ計算の論理エラー
```python
# ❌ 間違い（常に累積時間を返す）
lap_elapsed = total

# ✅ 正しい（前回からの差分）
if len(laps) == 0:
    lap_elapsed = total
else:
    lap_elapsed = total - laps[-1]["total_elapsed_ms"]
```

### 間違い 4: 非同期処理の await 忘れ
```javascript
// ❌ 間違い（Promiseが返る）
const t = api("/timer");

// ✅ 正しい（値が返る）
const t = await api("/timer");
```

### 間違い 5: requestAnimationFrame の無限ループ
```javascript
// ❌ 間違い（一度しか実行されない）
function renderTimer() {
  $("time").textContent = fmt(ms);
}

// ✅ 正しい（継続的に実行）
function renderTimer() {
  $("time").textContent = fmt(ms);
  requestAnimationFrame(renderTimer);
}
```

---

## デバッグのコツ

### 1. console.log() を活用
```javascript
async function syncTimer() {
  const t = await api("/timer");
  console.log("Timer state:", t);  // デバッグ出力
  t_state = t.state;
}
```

### 2. ブラウザの開発者ツール
- Network タブ: API通信を確認
- Console タブ: エラーメッセージを確認
- Elements タブ: DOM構造を確認

### 3. Python のprintデバッグ
```python
@app.post("/timer/start")
def start_timer():
    global state, start_time
    print(f"Before: state={state}, start_time={start_time}")  # デバッグ
    state = "running"
    start_time = time.monotonic()
    print(f"After: state={state}, start_time={start_time}")  # デバッグ
    return jsonify({"state": state}), 200
```

### 4. エラーメッセージを読む
- どのファイルの何行目でエラーが発生したか
- どんな種類のエラーか（SyntaxError, TypeError, etc.）
- エラーメッセージの内容

---

## 完成度チェックリスト

### バックエンド
- [ ] すべてのエンドポイントが実装されている
- [ ] エラーケースが正しく処理されている
- [ ] 時間計算が正確
- [ ] global 宣言が適切
- [ ] HTTPステータスコードが適切

### フロントエンド
- [ ] タイマー表示が滑らか（60fps）
- [ ] ボタン操作が正常に動作
- [ ] ラップが正しく表示される
- [ ] 時計が自動更新される
- [ ] エラー時も動作が継続する

### 全体
- [ ] 仕様書の要件をすべて満たしている
- [ ] テストシナリオをすべてクリア
- [ ] コードが読みやすい
- [ ] コメントが適切

すべてチェックできたら完成です！🎉

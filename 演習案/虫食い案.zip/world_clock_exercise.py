from datetime import datetime
from zoneinfo import ZoneInfo
from flask import jsonify, request


# =========================
# Clock（世界時計）設定
# =========================
# TODO 6-1: 対応するタイムゾーンの辞書を定義
# キー: タイムゾーン名、値: ZoneInfo用の文字列
# サポートするタイムゾーン:
# - UTC
# - Asia/Tokyo
# - America/New_York
# - Europe/London
ALLOWED_TZ = {
    ____: ____,
    ____: ____,
    ____: ____,
    ____: ____,
}


def register_clock_routes(app):
    """世界時計機能のエンドポイントを登録"""
    
    @app.get("/clock")
    def get_clock():
        """
        指定されたタイムゾーンの現在時刻を取得
        
        Query Parameters:
            tz: タイムゾーン（デフォルト: UTC）
        
        Returns:
            200: 時刻情報
            400: 無効なタイムゾーン
        """
        # TODO 6-2: クエリパラメータから tz を取得
        # ヒント: request.args.get() を使用
        # ヒント: デフォルト値は "UTC"
        tz = ____
        
        # TODO 6-3: タイムゾーンが許可リストにあるか確認
        # 無効な場合は 400 エラーを返す
        # ヒント: エラーコードは "INVALID_TIMEZONE"
        if ____:
            return ____, ____
        
        # TODO 6-4: 指定されたタイムゾーンで現在時刻を取得
        # ヒント: datetime.now() に ZoneInfo() を渡す
        # ヒント: ALLOWED_TZ[tz] でタイムゾーン文字列を取得
        now = ____
        
        # TODO 6-5: レスポンスを作成して返す
        # - tz: タイムゾーン名
        # - iso: ISO 8601 形式の時刻文字列（now.isoformat()）
        # - epoch_ms: Unix エポックからのミリ秒（now.timestamp() * 1000）
        return (
            jsonify({
                "tz": ____,
                "iso": ____,
                "epoch_ms": ____,  # ヒント: int() でキャスト
            }),
            200,
        )

    return get_clock
